/*!
@file splashscreen.c
@author Low Ee Loong (eeloong.l)
@course Computer Science in Real-Time Interactive Simulation
@section csd1401f22-a.sg
@Project Splashscreen
@date 12/09/2022
@brief This file displays a flashing image of Digipen Singapore's logo every 2 seconds
*/
/*______________________________________________________________________*/


#include "cprocessing.h"
#include <stdio.h>
#include <stdlib.h>
CP_Image logo;
CP_Color red;
float size = 30.0;
int alpha = 255;
float seconds = 2;
float ms = 0;
float polling = 0;
float systime = 0;

/*!
@brief	Sets the image of the digipen logo
		Sets colour red
		Sets the polling rate of logo refresh
@param void.
@return void.
*/
/*______________________________________________________________*/

void splash_screen_init(void)
{
	CP_System_SetFrameRate(60.0f);
	logo = CP_Image_Load("Assets/DigiPen_BLACK.png");
	CP_Settings_ImageMode(CP_POSITION_CORNER);
	CP_Settings_ImageWrapMode(CP_IMAGE_WRAP_CLAMP);
	CP_System_SetWindowSize(CP_Image_GetWidth(logo), CP_Image_GetHeight(logo));
	red = CP_Color_Create(255, 0, 0, 255);
	ms = seconds * 1000;
	polling = alpha / ms;
}

/*!
@brief	Clears Background
		Fades logo out every 2 seconds
		Draws a circle where the mouse position is
@param void.
@return void.
*/
/*______________________________________________________________*/

void splash_screen_update(void)
{
	CP_Graphics_ClearBackground(CP_Color_Create(50, 50, 50, 255));
	systime = CP_System_GetMillis();
	alpha = (int)(systime * polling) % 255;
	CP_Image_Draw(logo, 0.f, 0.f, CP_Image_GetWidth(logo), CP_Image_GetHeight(logo), alpha);
	CP_Settings_NoStroke();
	CP_Settings_Fill(red);
	CP_Graphics_DrawEllipse(CP_Input_GetMouseX(), CP_Input_GetMouseY(), size, size);
	
	if (CP_Input_KeyDown(KEY_Q))
	{
		CP_Engine_Terminate();
	}

}

void splash_screen_exit(void)
{
	CP_Image_Free(&logo);
}