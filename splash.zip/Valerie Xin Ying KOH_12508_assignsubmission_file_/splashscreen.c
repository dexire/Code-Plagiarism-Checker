#pragma once
#include "cprocessing.h"

CP_Image digipenLogo = NULL;
int alpha = 0;

void splash_screen_init(void)
{
	digipenLogo = CP_Image_Load("./Assets/DigiPen_BLACK.png");

	CP_Settings_ImageMode(CP_POSITION_CORNER);
	CP_Settings_ImageWrapMode(CP_IMAGE_WRAP_CLAMP);

	CP_System_SetWindowSize(CP_Image_GetWidth(digipenLogo), CP_Image_GetHeight(digipenLogo));
	CP_Color Red = CP_Color_Create(255, 0, 0, 255);

	CP_Settings_Fill(Red);
}

void splash_screen_update(void)
{
	CP_Graphics_ClearBackground(CP_Color_Create(100, 100, 100, 255));

	alpha += 255 / 120 * 1;
	alpha = alpha % 256;

	CP_Image_Draw(digipenLogo, 0, 0, CP_Image_GetWidth(digipenLogo), CP_Image_GetHeight(digipenLogo) , alpha);

	CP_Graphics_DrawCircle(CP_Input_GetMouseX(), CP_Input_GetMouseY(), 20);
}

void splash_screen_exit(void)
{
	CP_Image_Free(digipenLogo);
}