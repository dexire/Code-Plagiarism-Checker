#include "cprocessing.h"
#include "splashscreen.h"
#include <stdbool.h>
//#include <stdio.h>

CP_Image logo;
CP_Color blue;

void splash_screen_init(void)
{
	CP_Settings_ImageMode(CP_POSITION_CENTER);
	CP_Settings_ImageWrapMode(CP_IMAGE_WRAP_CLAMP);
	CP_System_SetWindowSize(1024, 720);

	logo = CP_Image_Load("Assets/DigiPen_Singapore_WEB_BLACK.png");
	blue = CP_Color_Create(0, 0, 255, 255);
}

void splash_screen_update(void)
{
	//Splash screen fade in/out effect
	static float alpha = 0; 
	static bool isFadingIn = true;
	static float time = 0;
	
	if (isFadingIn)
	{
		time += CP_System_GetDt();
		alpha = LinearInterpolate(2, time);

		if (alpha >= 255)
			isFadingIn = false;
	}
	else
	{
		time -= CP_System_GetDt();
		alpha = LinearInterpolate(2, time);

		if (alpha <= 0)
			isFadingIn = true;
	}

	/*char str[20];
	sprintf_s(str, 20, "%f", time);
	CP_System_SetWindowTitle(str);*/

	//Draw the splash logo
	CP_Image_Draw(logo, CP_System_GetWindowWidth() * 0.5f, CP_System_GetWindowHeight() * 0.5f, CP_Image_GetWidth(logo) * 0.5f, CP_Image_GetHeight(logo) * 0.5f, alpha);

	//Draw the the circle on Mouse Pos
	CP_Graphics_DrawCircle(CP_Input_GetMouseX(), CP_Input_GetMouseY(), 50);

	//Clear
	CP_Graphics_ClearBackground(blue);
}

void splash_screen_exit(void)
{
	CP_Image_Free(&logo);
}

/// <summary>
/// Calculates the alpha during the fade effect
/// </summary>
/// <param name="float fadeTime = Length of fade effect (in seconds)"></param>
/// <param name="float timeElapsed = Elapsed time since start of fade effect"></param>
/// <returns>Returns a float</returns>
float LinearInterpolate(float fadeTime, float timeElapsed)
{
	return (255 / fadeTime) * timeElapsed;
}