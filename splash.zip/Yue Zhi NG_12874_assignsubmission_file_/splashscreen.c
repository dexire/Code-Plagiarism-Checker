#include <stdio.h>
#include <cprocessing.h>
CP_Image SS_img = NULL;
CP_Color SS_colour1;
CP_Color SS_colour2;
CP_Color SS_colour3;
int SS_width = 0;
int SS_height = 0;
int alpha = 0;
float seconds = 2;
int max_alpha = 255;

void splash_screen_init(void)
{
    SS_img = CP_Image_Load("./Assets/Digipen_Black.png");
    SS_width = CP_Image_GetWidth(SS_img);
    SS_height = CP_Image_GetHeight(SS_img);
    SS_colour1 = CP_Color_Create(50, 50, 50, 255);
    SS_colour2 = CP_Color_Create(100, 100, 100, 255);
    SS_colour3 = CP_Color_Create(200, 200, 200, 255);
    CP_Settings_ImageMode(CP_POSITION_CORNER);
    CP_System_SetWindowSize(SS_width, SS_height);
    CP_Graphics_ClearBackground(SS_colour1);

}


void splash_screen_update(void)
{
  
        CP_Graphics_ClearBackground(SS_colour1);
        CP_Image_Draw(SS_img, 0, 0, SS_width, SS_height, alpha);       
        CP_Graphics_DrawCircle(CP_Input_GetMouseX(), CP_Input_GetMouseY(), 30);
        float currentElapsedTime = CP_System_GetDt();
        alpha += (int)(currentElapsedTime * (max_alpha / seconds));
        alpha %= max_alpha + 1;

        
      
    }



void splash_screen_exit(void)
{
 CP_Image_Free(&SS_img);
}