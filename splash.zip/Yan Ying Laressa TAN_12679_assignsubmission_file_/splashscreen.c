#include "cprocessing.h"
#include <stdlib.h>

CP_Image logo;
int Alpha;

void splash_screen_init(void)
{
	Alpha = 0;
	logo = CP_Image_Load("Assets/DigiPen_BLACK.png");
	CP_Settings_ImageMode(CP_POSITION_CORNER);
	CP_Settings_ImageWrapMode(CP_IMAGE_WRAP_CLAMP);

	CP_System_SetWindowSize(CP_Image_GetWidth(logo), CP_Image_GetHeight(logo));
}

void splash_screen_update(void)
{
	Alpha = Alpha % 256 + 255 / (2 / CP_System_GetDt()); 
	CP_Image_Draw(logo, 0.f, 0.f, CP_Image_GetWidth(logo), CP_Image_GetHeight(logo), Alpha);
	CP_Settings_Fill(CP_Color_Create(255, 0, 0, 255));
	CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawCircle(CP_Input_GetMouseX(), CP_Input_GetMouseY(), 25);
}

void splash_screen_exit(void)
{
	CP_Image_Free(&logo);
	CP_Engine_SetNextGameState;
}
