#pragma once
void splash_screen_init(void);
void splash_screen_update(void);
void splash_screen_exit(void);