#include "cprocessing.h"
CP_Image logo;
int x = 0;
int i = 1;

static float totalElapsedTime = 0;

void splash_screen_init(void)
{

	logo = CP_Image_Load("Assets/DigiPen_BLACK.png");
	CP_Settings_ImageMode(CP_POSITION_CORNER);
	CP_Settings_ImageWrapMode(CP_IMAGE_WRAP_CLAMP);
	CP_System_SetWindowSize(CP_Image_GetWidth(logo), CP_Image_GetHeight(logo));
	
}

void splash_screen_update(void)
{
	int alpha = 0, timer = 0, seconds = 2;
	float elapsedTime = CP_System_GetDt();

	totalElapsedTime += elapsedTime;
	timer = totalElapsedTime *(256/seconds);
	alpha = timer %256;

	CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));
	CP_Image_Draw(logo, 0.f, 0.f, CP_Image_GetWidth(logo), CP_Image_GetHeight(logo), alpha);

	CP_Settings_Fill(CP_Color_Create(255, 0, 0, 255));
	CP_Graphics_DrawCircle(CP_Input_GetMouseX(), CP_Input_GetMouseY(), 25.0f, 25.0f);

	if (CP_Input_KeyDown(KEY_Q))
	{
		CP_Engine_Terminate();
	}
}

void splash_screen_exit(void)
{
	CP_Image_Free(&logo);
}